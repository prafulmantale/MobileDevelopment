package com.bulletnoid.android.widget.StaggeredGridViewDemo;

public class Item {
    public String url;
    public int width;
    public int height;
}
