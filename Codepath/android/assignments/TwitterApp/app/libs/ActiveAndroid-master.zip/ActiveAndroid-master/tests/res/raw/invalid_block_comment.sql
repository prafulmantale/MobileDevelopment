CREATE TABLE Entity1
(
	Id INTEGER AUTOINCREMENT PRIMARY KEY NOT NULL,
	 /* /* /* This is an invalid block comment */ */
	Column1 INTEGER
)
