CREATE TABLE Entity1
(
	Id INTEGER AUTOINCREMENT PRIMARY KEY NOT NULL,
	-- This is a line comment and should be ignored */ NonColumn STRING,
	Column1 INTEGER
)
